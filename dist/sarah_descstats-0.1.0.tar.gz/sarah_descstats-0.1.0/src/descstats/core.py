import statistics as _stats

def mean(values):
    return _stats.mean(values)

def median(values):
    return _stats.median(values)

def mode(values):
    return _stats.mode(values) 

def data_range(values): 
    return max(values) - min(values)

def describe(values):
    return {
        "count": len(values),
        "mean": mean(values),
        "median": median(values),
        "mode": mode(values),
        "min": min(values),
        "max": max(values),
        "range": data_range(values),
    }
